
import { useAuthStore } from '../authStore';
import { useChatStore } from './chatStore';
import { getSocket } from '../socketClient';
import { encryptMessage } from '../encryption';
import { toast } from 'sonner';
import { getOrCreateConversation } from './conversationUtils';

export const sendMessage = async (recipientId: string, content: string) => {
  const conversation = await getOrCreateConversation(recipientId);
  const currentUser = useAuthStore.getState().user;
  
  if (!currentUser) {
    throw new Error('User not authenticated');
  }
  
  // Generate message ID
  const messageId = `msg_${Math.random().toString(36).substr(2, 9)}`;
  
  // Encrypt the message
  const encryptedContent = encryptMessage(content, conversation.sessionKey || '');
  
  const newMessage = {
    id: messageId,
    senderId: currentUser.id,
    recipientId,
    content: encryptedContent,
    encrypted: true,
    timestamp: new Date(),
    status: 'sent' as const
  };
  
  try {
    // Send via socket if connected
    const socket = getSocket();
    if (socket && socket.connected) {
      socket.emit('private_message', {
        messageId,
        recipientId,
        content: encryptedContent,
        encrypted: true
      });
    } else {
      console.warn('Socket not connected, message will be stored locally only');
    }
    
    // Update local state
    useChatStore.setState(state => ({
      conversations: state.conversations.map(c => {
        if (c.id === conversation.id) {
          return {
            ...c,
            messages: [...c.messages, newMessage],
            lastMessage: newMessage
          };
        }
        return c;
      })
    }));
    
    // Simulate received status after a short delay (for demo purposes)
    setTimeout(() => {
      useChatStore.setState(state => ({
        conversations: state.conversations.map(c => {
          if (c.id === conversation.id) {
            return {
              ...c,
              messages: c.messages.map(m => {
                if (m.id === messageId) {
                  return { ...m, status: 'delivered' };
                }
                return m;
              })
            };
          }
          return c;
        })
      }));
    }, 1000);
    
    return;
    
  } catch (error) {
    console.error('Error sending message:', error);
    toast.error('Failed to send message. Please try again.');
    throw error;
  }
};
