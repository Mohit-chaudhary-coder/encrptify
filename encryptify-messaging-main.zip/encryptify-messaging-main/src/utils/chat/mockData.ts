
import { User } from './types';

export const mockUsers: User[] = [
  { id: 'user_1', username: 'alice', publicKey: 'pk_alice', isOnline: true },
  { id: 'user_2', username: 'bob', publicKey: 'pk_bob', isOnline: false, lastSeen: new Date(Date.now() - 120000) },
  { id: 'user_3', username: 'charlie', publicKey: 'pk_charlie', isOnline: true },
  { id: 'user_4', username: 'diana', publicKey: 'pk_diana', isOnline: false, lastSeen: new Date(Date.now() - 3600000) },
];
