
export interface User {
  id: string;
  username: string;
  publicKey: string;
  isOnline?: boolean;
  lastSeen?: Date;
}

export interface Message {
  id: string;
  senderId: string;
  recipientId: string;
  content: string;
  encrypted: boolean;
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

export interface Conversation {
  id: string;
  participants: User[];
  messages: Message[];
  lastMessage?: Message;
  sessionKey?: string;
}

export interface ChatState {
  users: User[];
  conversations: Conversation[];
  activeConversationId: string | null;
  
  fetchUsers: () => Promise<void>;
  sendMessage: (recipientId: string, content: string) => Promise<void>;
  getOrCreateConversation: (recipientId: string) => Promise<Conversation>;
  setActiveConversation: (conversationId: string) => void;
  markAsRead: (messageId: string) => void;
  setupSocketListeners: () => void;
}
