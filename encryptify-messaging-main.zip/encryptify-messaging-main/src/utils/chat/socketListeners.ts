
import { getSocket } from '../socketClient';
import { useAuthStore } from '../authStore';
import { useChatStore } from './chatStore';
import { toast } from 'sonner';
import { User } from './types';

export const setupSocketListeners = () => {
  const socket = getSocket();
  if (!socket) {
    try {
      const { initializeSocket } = require('../socketClient');
      initializeSocket();
    } catch (error) {
      console.error('Failed to initialize socket in setupSocketListeners:', error);
      return;
    }
  }

  const currentSocket = getSocket();
  if (!currentSocket) return;
  
  // Listen for new messages
  currentSocket.on('private_message', (data: {
    id: string;
    senderId: string;
    content: string;
    timestamp: Date;
    encrypted: boolean;
  }) => {
    const { senderId, content, encrypted } = data;
    const currentUser = useAuthStore.getState().user;
    
    if (!currentUser) return;
    
    // Find or create conversation for this sender
    useChatStore.getState().getOrCreateConversation(senderId).then(conversation => {
      // Add the received message to the conversation
      const newMessage = {
        id: data.id,
        senderId,
        recipientId: currentUser.id,
        content,
        encrypted,
        timestamp: new Date(data.timestamp),
        status: 'delivered' as const
      };
      
      useChatStore.setState(state => ({
        conversations: state.conversations.map(c => {
          if (c.id === conversation.id) {
            return {
              ...c,
              messages: [...c.messages, newMessage],
              lastMessage: newMessage
            };
          }
          return c;
        })
      }));
      
      // Show toast notification for new message
      if (useChatStore.getState().activeConversationId !== conversation.id) {
        const sender = useChatStore.getState().users.find(u => u.id === senderId);
        toast(`New message from ${sender?.username || 'someone'}`, {
          description: encrypted ? '🔒 Encrypted message' : content.substring(0, 30)
        });
      }
      
      // Auto-mark as read if conversation is active
      if (useChatStore.getState().activeConversationId === conversation.id) {
        currentSocket.emit('message_read', {
          messageId: data.id,
          senderId
        });
      }
    });
  });
  
  // Listen for online status changes
  currentSocket.on('user_status_change', (data: { userId: string; status: 'online' | 'offline'; lastSeen?: Date }) => {
    useChatStore.setState(state => ({
      users: state.users.map(user => {
        if (user.id === data.userId) {
          return {
            ...user,
            isOnline: data.status === 'online',
            lastSeen: data.status === 'offline' ? new Date(data.lastSeen || Date.now()) : user.lastSeen
          };
        }
        return user;
      })
    }));
  });
  
  // Listen for message status updates
  currentSocket.on('message_status', (data: { messageId: string; status: 'delivered' | 'read' }) => {
    useChatStore.setState(state => ({
      conversations: state.conversations.map(c => {
        return {
          ...c,
          messages: c.messages.map(m => {
            if (m.id === data.messageId) {
              return { ...m, status: data.status };
            }
            return m;
          })
        };
      })
    }));
  });
};
