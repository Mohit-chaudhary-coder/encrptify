
import { useAuthStore } from '../authStore';
import { useChatStore } from './chatStore';
import { generateSessionKey } from '../encryption';
import { Conversation } from './types';

export const getOrCreateConversation = async (recipientId: string): Promise<Conversation> => {
  const { conversations, users } = useChatStore.getState();
  const currentUser = useAuthStore.getState().user;
  
  if (!currentUser) {
    throw new Error('User not authenticated');
  }
  
  // Find existing conversation
  let conversation = conversations.find(c => 
    c.participants.some(p => p.id === currentUser.id) && 
    c.participants.some(p => p.id === recipientId)
  );
  
  if (!conversation) {
    // Find recipient user
    const recipient = users.find(u => u.id === recipientId);
    
    if (!recipient) {
      throw new Error('Recipient not found');
    }
    
    // Create a new conversation
    const newConversation: Conversation = {
      id: `conv_${Math.random().toString(36).substr(2, 9)}`,
      participants: [
        {
          id: currentUser.id,
          username: currentUser.username,
          publicKey: currentUser.publicKey
        },
        recipient
      ],
      messages: [],
      sessionKey: generateSessionKey(currentUser.privateKey, recipient.publicKey)
    };
    
    useChatStore.setState(state => ({ 
      conversations: [...state.conversations, newConversation]
    }));
    
    return newConversation;
  }
  
  return conversation;
};

export const setActiveConversation = (conversationId: string) => {
  useChatStore.setState({ activeConversationId: conversationId });
};

export const markAsRead = (messageId: string) => {
  useChatStore.setState(state => ({
    conversations: state.conversations.map(c => {
      return {
        ...c,
        messages: c.messages.map(m => {
          if (m.id === messageId && m.status !== 'read') {
            return { ...m, status: 'read' };
          }
          return m;
        })
      };
    })
  }));
};
