
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ChatState } from './types';
import { setupSocketListeners } from './socketListeners';
import { getOrCreateConversation, setActiveConversation, markAsRead } from './conversationUtils';
import { sendMessage } from './messageUtils';
import { fetchUsers } from './userUtils';

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      users: [],
      conversations: [],
      activeConversationId: null,
      setupSocketListeners,
      fetchUsers,
      getOrCreateConversation,
      setActiveConversation,
      sendMessage,
      markAsRead,
    }),
    {
      name: 'encryptify-chat-storage',
      partialize: (state) => ({ 
        conversations: state.conversations.map(conv => ({
          ...conv,
          sessionKey: undefined
        })),
        activeConversationId: state.activeConversationId
      })
    }
  )
);
