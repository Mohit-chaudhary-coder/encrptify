
import { useChatStore } from './chatStore';
import { getSocket } from '../socketClient';
import { User } from './types';
import { mockUsers } from './mockData';

export const fetchUsers = async (): Promise<void> => {
  try {
    const socket = getSocket();
    
    if (socket && socket.connected) {
      // Request user list from server
      socket.emit('get_users');
      
      // Wait for response
      const users = await new Promise<User[]>((resolve, reject) => {
        socket.once('users_list', (data) => resolve(data));
        socket.once('error', (error) => reject(error));
        
        // Timeout after 5 seconds
        setTimeout(() => reject(new Error('Timeout getting users')), 5000);
      });
      
      useChatStore.setState({ users });
    } else {
      // Fallback to mock data if socket not connected
      console.log('Socket not connected, using mock data');
      useChatStore.setState({ users: mockUsers });
    }
  } catch (error) {
    console.error('Error fetching users:', error);
    // Fallback to mock data on error
    useChatStore.setState({ users: mockUsers });
  }
};
