
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { generateKeyPair, generateSessionToken } from './encryption';

interface User {
  id: string;
  username: string;
  email: string;
  publicKey: string;
  privateKey: string;
}

interface AuthState {
  user: User | null;
  sessionToken: string | null;
  isLoggedIn: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (username: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

// In a real application, these would be API calls to a backend service
// This is a demo implementation that simulates the functionality

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      sessionToken: null,
      isLoggedIn: false,
      
      login: async (email, password) => {
        // Simulate API call and authentication
        try {
          // In a real app, this would be a fetch to your API
          // For demo purposes, we'll simulate a successful login
          
          // Simulate waiting for server response
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          // Create mock user with generated keys
          const keys = generateKeyPair();
          const user: User = {
            id: `user_${Math.random().toString(36).substr(2, 9)}`,
            username: email.split('@')[0],
            email,
            ...keys
          };
          
          const sessionToken = generateSessionToken();
          
          set({ 
            user, 
            sessionToken,
            isLoggedIn: true 
          });
          
          return true;
        } catch (error) {
          console.error('Login failed:', error);
          return false;
        }
      },
      
      register: async (username, email, password) => {
        // Simulate API call for registration
        try {
          // In a real app, this would be a fetch to your API
          // For demo purposes, we'll simulate a successful registration
          
          // Simulate waiting for server response
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          // In a real app, the key pair would be generated on the client
          // and only the public key would be sent to the server
          const keys = generateKeyPair();
          
          const user: User = {
            id: `user_${Math.random().toString(36).substr(2, 9)}`,
            username,
            email,
            ...keys
          };
          
          const sessionToken = generateSessionToken();
          
          set({ 
            user, 
            sessionToken,
            isLoggedIn: true 
          });
          
          return true;
        } catch (error) {
          console.error('Registration failed:', error);
          return false;
        }
      },
      
      logout: () => {
        set({ 
          user: null, 
          sessionToken: null,
          isLoggedIn: false 
        });
      }
    }),
    {
      name: 'encryptify-auth-storage',
      partialize: (state) => ({ 
        user: state.user,
        sessionToken: state.sessionToken,
        isLoggedIn: state.isLoggedIn
      })
    }
  )
);
