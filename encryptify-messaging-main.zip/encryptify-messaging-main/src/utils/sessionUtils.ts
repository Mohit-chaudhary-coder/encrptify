import { useAuthStore } from './authStore';

// Session activity timeout in milliseconds (30 minutes)
const SESSION_TIMEOUT = 30 * 60 * 1000;

// Keep track of user activity
let lastActivityTime = Date.now();

// Update the last activity time
const updateActivity = () => {
  lastActivityTime = Date.now();
};

// Check if the session has timed out
const isSessionTimedOut = () => {
  return Date.now() - lastActivityTime > SESSION_TIMEOUT;
};

// Initialize session monitoring
export const initSessionMonitoring = () => {
  // Set up activity listeners
  const activityEvents = ['mousedown', 'keydown', 'touchstart', 'scroll'];
  
  activityEvents.forEach(event => {
    window.addEventListener(event, updateActivity);
  });
  
  // Check for session timeout periodically
  setInterval(() => {
    if (useAuthStore.getState().isLoggedIn && isSessionTimedOut()) {
      console.log('Session timed out due to inactivity');
      useAuthStore.getState().logout();
      window.location.href = '/login?timeout=true';
    }
  }, 60000); // Check every minute
  
  // Update activity on initial load
  updateActivity();
};

// Rate limiting for login attempts
const loginAttempts = new Map<string, { count: number, lastAttempt: number }>();

export const checkLoginRateLimit = (email: string): boolean => {
  const now = Date.now();
  const attempts = loginAttempts.get(email) || { count: 0, lastAttempt: now };
  
  // Reset attempts if last attempt was more than 15 minutes ago
  if (now - attempts.lastAttempt > 15 * 60 * 1000) {
    attempts.count = 0;
  }
  
  attempts.count++;
  attempts.lastAttempt = now;
  loginAttempts.set(email, attempts);
  
  // Rate limit: 5 attempts per 15 minutes
  return attempts.count <= 5;
};

// Log security events
export const logSecurityEvent = (event: string, details: Record<string, any>) => {
  const user = useAuthStore.getState().user;
  const userId = user?.id || 'unauthenticated';
  
  const logEntry = {
    timestamp: new Date().toISOString(),
    userId,
    event,
    details,
    userAgent: navigator.userAgent,
    ip: 'client-side' // In a real app, this would be set server-side
  };
  
  console.log('Security event:', logEntry);
  
  // In a real app, this would send the log to the server
  // fetch('/api/security/log', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(logEntry)
  // });
};
