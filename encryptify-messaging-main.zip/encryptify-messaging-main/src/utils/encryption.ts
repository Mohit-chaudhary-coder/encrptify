
import CryptoJS from 'crypto-js';

// Generate a key pair for a user
export const generateKeyPair = (): { publicKey: string; privateKey: string } => {
  // In a real app, we would use WebCrypto API for proper asymmetric encryption
  // This is a simplified demo version that simulates key pair generation
  const privateKey = CryptoJS.lib.WordArray.random(32).toString();
  const publicKey = CryptoJS.SHA256(privateKey).toString();
  
  return {
    privateKey,
    publicKey
  };
};

// Generate a shared secret for two users to communicate
export const generateSessionKey = (myPrivateKey: string, theirPublicKey: string): string => {
  // In a real app, this would use proper Diffie-Hellman or similar
  // This is a simplified version for demo purposes
  return CryptoJS.SHA256(myPrivateKey + theirPublicKey).toString();
};

// Encrypt a message using the session key
export const encryptMessage = (message: string, sessionKey: string): string => {
  return CryptoJS.AES.encrypt(message, sessionKey).toString();
};

// Decrypt a message using the session key
export const decryptMessage = (encryptedMessage: string, sessionKey: string): string => {
  const bytes = CryptoJS.AES.decrypt(encryptedMessage, sessionKey);
  return bytes.toString(CryptoJS.enc.Utf8);
};

// Hash a password with salt for secure storage
export const hashPassword = (password: string): string => {
  const salt = CryptoJS.lib.WordArray.random(128/8).toString();
  const hash = CryptoJS.PBKDF2(password, salt, { keySize: 512/32, iterations: 1000 }).toString();
  return salt + ':' + hash;
};

// Verify a password against a stored hash
export const verifyPassword = (password: string, storedHash: string): boolean => {
  const [salt, hash] = storedHash.split(':');
  const calculatedHash = CryptoJS.PBKDF2(password, salt, { keySize: 512/32, iterations: 1000 }).toString();
  return hash === calculatedHash;
};

// Generate a secure session token
export const generateSessionToken = (): string => {
  return CryptoJS.lib.WordArray.random(64).toString();
};
