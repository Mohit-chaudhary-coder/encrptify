import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { encryptMessage, decryptMessage, generateSessionKey } from './encryption';
import { useAuthStore } from './authStore';
import { getSocket, emitEncryptedMessage, initializeSocket } from './socketClient';
import { toast } from 'sonner';

interface User {
  id: string;
  username: string;
  publicKey: string;
  isOnline?: boolean;
  lastSeen?: Date;
}

interface Message {
  id: string;
  senderId: string;
  recipientId: string;
  content: string;
  encrypted: boolean;
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

interface Conversation {
  id: string;
  participants: User[];
  messages: Message[];
  lastMessage?: Message;
  sessionKey?: string;
}

interface ChatState {
  users: User[];
  conversations: Conversation[];
  activeConversationId: string | null;
  
  fetchUsers: () => Promise<void>;
  sendMessage: (recipientId: string, content: string) => Promise<void>;
  getOrCreateConversation: (recipientId: string) => Promise<Conversation>;
  setActiveConversation: (conversationId: string) => void;
  markAsRead: (messageId: string) => void;
  setupSocketListeners: () => void;
}

const mockUsers: User[] = [
  { id: 'user_1', username: 'alice', publicKey: 'pk_alice', isOnline: true },
  { id: 'user_2', username: 'bob', publicKey: 'pk_bob', isOnline: false, lastSeen: new Date(Date.now() - 120000) },
  { id: 'user_3', username: 'charlie', publicKey: 'pk_charlie', isOnline: true },
  { id: 'user_4', username: 'diana', publicKey: 'pk_diana', isOnline: false, lastSeen: new Date(Date.now() - 3600000) },
];

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      users: [],
      conversations: [],
      activeConversationId: null,
      
      setupSocketListeners: () => {
        const socket = getSocket();
        if (!socket) {
          try {
            initializeSocket();
          } catch (error) {
            console.error('Failed to initialize socket in setupSocketListeners:', error);
            return;
          }
        }

        const currentSocket = getSocket();
        if (!currentSocket) return;
        
        // Listen for new messages
        currentSocket.on('private_message', (data: {
          id: string;
          senderId: string;
          content: string;
          timestamp: Date;
          encrypted: boolean;
        }) => {
          const { senderId, content, encrypted } = data;
          const currentUser = useAuthStore.getState().user;
          
          if (!currentUser) return;
          
          // Find or create conversation for this sender
          get().getOrCreateConversation(senderId).then(conversation => {
            // Add the received message to the conversation
            const newMessage = {
              id: data.id,
              senderId,
              recipientId: currentUser.id,
              content,
              encrypted,
              timestamp: new Date(data.timestamp),
              status: 'delivered' as const
            };
            
            set(state => ({
              conversations: state.conversations.map(c => {
                if (c.id === conversation.id) {
                  return {
                    ...c,
                    messages: [...c.messages, newMessage],
                    lastMessage: newMessage
                  };
                }
                return c;
              })
            }));
            
            // Show toast notification for new message
            if (get().activeConversationId !== conversation.id) {
              const sender = get().users.find(u => u.id === senderId);
              toast(`New message from ${sender?.username || 'someone'}`, {
                description: encrypted ? '🔒 Encrypted message' : content.substring(0, 30)
              });
            }
            
            // Auto-mark as read if conversation is active
            if (get().activeConversationId === conversation.id) {
              currentSocket.emit('message_read', {
                messageId: data.id,
                senderId
              });
            }
          });
        });
        
        // Listen for online status changes
        currentSocket.on('user_status_change', (data: { userId: string; status: 'online' | 'offline'; lastSeen?: Date }) => {
          set(state => ({
            users: state.users.map(user => {
              if (user.id === data.userId) {
                return {
                  ...user,
                  isOnline: data.status === 'online',
                  lastSeen: data.status === 'offline' ? new Date(data.lastSeen || Date.now()) : user.lastSeen
                };
              }
              return user;
            })
          }));
        });
        
        // Listen for message status updates
        currentSocket.on('message_status', (data: { messageId: string; status: 'delivered' | 'read' }) => {
          set(state => ({
            conversations: state.conversations.map(c => {
              return {
                ...c,
                messages: c.messages.map(m => {
                  if (m.id === data.messageId) {
                    return { ...m, status: data.status };
                  }
                  return m;
                })
              };
            })
          }));
        });
      },
      
      fetchUsers: async () => {
        try {
          const socket = getSocket();
          
          if (socket && socket.connected) {
            // Request user list from server
            socket.emit('get_users');
            
            // Wait for response
            const users = await new Promise<User[]>((resolve, reject) => {
              socket.once('users_list', (data) => resolve(data));
              socket.once('error', (error) => reject(error));
              
              // Timeout after 5 seconds
              setTimeout(() => reject(new Error('Timeout getting users')), 5000);
            });
            
            set({ users });
          } else {
            // Fallback to mock data if socket not connected
            console.log('Socket not connected, using mock data');
            set({ users: mockUsers });
          }
        } catch (error) {
          console.error('Error fetching users:', error);
          // Fallback to mock data on error
          set({ users: mockUsers });
        }
      },
      
      getOrCreateConversation: async (recipientId) => {
        const { conversations } = get();
        const currentUser = useAuthStore.getState().user;
        
        if (!currentUser) {
          throw new Error('User not authenticated');
        }
        
        // Find existing conversation
        let conversation = conversations.find(c => 
          c.participants.some(p => p.id === currentUser.id) && 
          c.participants.some(p => p.id === recipientId)
        );
        
        if (!conversation) {
          // Find recipient user
          const recipient = get().users.find(u => u.id === recipientId);
          
          if (!recipient) {
            throw new Error('Recipient not found');
          }
          
          // Create a new conversation
          const newConversation: Conversation = {
            id: `conv_${Math.random().toString(36).substr(2, 9)}`,
            participants: [
              {
                id: currentUser.id,
                username: currentUser.username,
                publicKey: currentUser.publicKey
              },
              recipient
            ],
            messages: [],
            sessionKey: generateSessionKey(currentUser.privateKey, recipient.publicKey)
          };
          
          set(state => ({ 
            conversations: [...state.conversations, newConversation]
          }));
          
          return newConversation;
        }
        
        return conversation;
      },
      
      sendMessage: async (recipientId, content) => {
        const conversation = await get().getOrCreateConversation(recipientId);
        const currentUser = useAuthStore.getState().user;
        
        if (!currentUser) {
          throw new Error('User not authenticated');
        }
        
        // Generate message ID
        const messageId = `msg_${Math.random().toString(36).substr(2, 9)}`;
        
        // Encrypt the message
        const encryptedContent = encryptMessage(content, conversation.sessionKey || '');
        
        const newMessage: Message = {
          id: messageId,
          senderId: currentUser.id,
          recipientId,
          content: encryptedContent,
          encrypted: true,
          timestamp: new Date(),
          status: 'sent'
        };
        
        try {
          // Send via socket if connected
          const socket = getSocket();
          if (socket && socket.connected) {
            socket.emit('private_message', {
              messageId,
              recipientId,
              content: encryptedContent,
              encrypted: true
            });
          } else {
            console.warn('Socket not connected, message will be stored locally only');
          }
          
          // Update local state
          set(state => ({
            conversations: state.conversations.map(c => {
              if (c.id === conversation.id) {
                return {
                  ...c,
                  messages: [...c.messages, newMessage],
                  lastMessage: newMessage
                };
              }
              return c;
            })
          }));
          
          // Simulate received status after a short delay (for demo purposes)
          setTimeout(() => {
            set(state => ({
              conversations: state.conversations.map(c => {
                if (c.id === conversation.id) {
                  return {
                    ...c,
                    messages: c.messages.map(m => {
                      if (m.id === messageId) {
                        return { ...m, status: 'delivered' };
                      }
                      return m;
                    })
                  };
                }
                return c;
              })
            }));
          }, 1000);
          
          return;
          
        } catch (error) {
          console.error('Error sending message:', error);
          toast.error('Failed to send message. Please try again.');
          throw error;
        }
      },
      
      setActiveConversation: (conversationId) => {
        set({ activeConversationId: conversationId });
      },
      
      markAsRead: (messageId) => {
        set(state => ({
          conversations: state.conversations.map(c => {
            return {
              ...c,
              messages: c.messages.map(m => {
                if (m.id === messageId && m.status !== 'read') {
                  return { ...m, status: 'read' };
                }
                return m;
              })
            };
          })
        }));
      }
    }),
    {
      name: 'encryptify-chat-storage',
      partialize: (state) => ({ 
        conversations: state.conversations.map(conv => ({
          ...conv,
          sessionKey: undefined
        })),
        activeConversationId: state.activeConversationId
      })
    }
  )
);
