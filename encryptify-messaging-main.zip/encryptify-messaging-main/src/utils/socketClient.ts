
import { io, Socket } from 'socket.io-client';
import { useAuthStore } from './authStore';
import { logSecurityEvent } from './sessionUtils';

// This would typically point to your production server
// For testing, you can use a free service like https://render.com or https://glitch.com
// to host a simple Node.js Socket.io server
const SOCKET_URL = 'https://encryptify-demo.glitch.me';

let socket: Socket | null = null;

export const initializeSocket = (): Socket => {
  if (socket) return socket;
  
  const { user, sessionToken } = useAuthStore.getState();
  
  if (!user || !sessionToken) {
    throw new Error('Cannot initialize socket without authentication');
  }

  // Connect with auth credentials
  socket = io(SOCKET_URL, {
    auth: {
      userId: user.id,
      sessionToken
    },
    autoConnect: true,
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000
  });
  
  socket.on('connect', () => {
    console.log('Socket connected successfully');
    logSecurityEvent('socket_connected', { socketId: socket?.id });
  });
  
  socket.on('connect_error', (error) => {
    console.error('Socket connection error:', error);
    logSecurityEvent('socket_connection_failed', { error: error.message });
  });
  
  socket.on('disconnect', (reason) => {
    console.log('Socket disconnected:', reason);
    logSecurityEvent('socket_disconnected', { reason });
  });
  
  return socket;
};

export const getSocket = (): Socket | null => {
  return socket;
};

export const disconnectSocket = (): void => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};

// Helper to emit events with encryption
export const emitEncryptedMessage = (
  eventName: string, 
  recipientId: string, 
  content: string, 
  sessionKey: string
): void => {
  const socket = getSocket();
  if (!socket) {
    throw new Error('Socket not initialized');
  }

  // In a real app, message encryption would happen here
  // This would use the encryption.ts functions
  socket.emit(eventName, {
    recipientId,
    content,
    encrypted: true,
    timestamp: new Date()
  });
};

