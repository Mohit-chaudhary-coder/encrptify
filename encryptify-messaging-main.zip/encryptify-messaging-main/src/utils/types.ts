
// Define common types for the application

export interface User {
  id: string;
  username: string;
  email?: string;
  publicKey: string;
  privateKey?: string;
  isOnline?: boolean;
  lastSeen?: Date;
}

export interface Message {
  id: string;
  senderId: string;
  recipientId: string;
  content: string;
  encrypted: boolean;
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

export interface Conversation {
  id: string;
  participants: User[];
  messages: Message[];
  lastMessage?: Message;
  sessionKey?: string;
}

export interface SecurityLog {
  timestamp: string;
  userId: string;
  event: string;
  details: Record<string, any>;
  userAgent: string;
  ip?: string;
}
