
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuthStore } from '@/utils/authStore';
import { Shield, ShieldCheck, Key } from 'lucide-react';
import { checkLoginRateLimit, logSecurityEvent } from '@/utils/sessionUtils';

export const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  
  const { login } = useAuthStore();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    try {
      // Check rate limiting before allowing login attempt
      if (!checkLoginRateLimit(email)) {
        setError('Too many login attempts. Please try again later.');
        logSecurityEvent('login_rate_limited', { email });
        setIsLoading(false);
        return;
      }
      
      const success = await login(email, password);
      if (success) {
        logSecurityEvent('login_successful', { email });
        navigate('/chat');
      } else {
        setError('Invalid email or password');
        logSecurityEvent('login_failed', { email, reason: 'invalid_credentials' });
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      logSecurityEvent('login_error', { email, error: String(err) });
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <div className="flex items-center justify-center mb-4">
          <ShieldCheck className="h-12 w-12 text-teal" />
        </div>
        <CardTitle className="text-center text-2xl">Secure Login</CardTitle>
        <CardDescription className="text-center">
          Enter your credentials to access your encrypted messages
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit}>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="pl-10"
                />
                <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="pl-10"
                />
                <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              </div>
            </div>
          </div>
          <Button 
            type="submit" 
            className="w-full mt-6 bg-teal hover:bg-teal/90"
            disabled={isLoading}
          >
            {isLoading ? 'Authenticating...' : 'Login'}
          </Button>
        </form>
      </CardContent>
      <CardFooter>
        <div className="text-center w-full">
          <p className="text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Button 
              variant="link" 
              className="p-0 h-auto text-teal"
              onClick={() => navigate('/register')}
            >
              Register
            </Button>
          </p>
        </div>
      </CardFooter>
    </Card>
  );
};
