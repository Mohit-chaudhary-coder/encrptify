
import { useState, useRef, useEffect } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuthStore } from "@/utils/authStore";
import { useChatStore } from "@/utils/chat/chatStore";
import { decryptMessage } from "@/utils/encryption";
import { EncryptionInfo } from "./EncryptionInfo";
import { Send, Lock, Shield, Phone, Video } from "lucide-react";

export const ChatWindow = () => {
  const [message, setMessage] = useState("");
  const { user } = useAuthStore();
  const { conversations, activeConversationId, sendMessage } = useChatStore();
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const activeConversation = conversations.find(
    (c) => c.id === activeConversationId
  );

  const otherParticipant = activeConversation?.participants.find(
    (p) => p.id !== user?.id
  );

  useEffect(() => {
    // Scroll to bottom when messages change or conversation changes
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [activeConversation?.messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !otherParticipant || !activeConversationId) return;

    sendMessage(otherParticipant.id, message);
    setMessage("");
  };

  // Get initials for avatar
  const getInitials = (name: string) => {
    return name?.substring(0, 2).toUpperCase() || "?";
  };

  // Decrypt message content if encrypted
  const getMessageContent = (msg: any) => {
    if (msg.encrypted && activeConversation?.sessionKey) {
      try {
        return decryptMessage(msg.content, activeConversation.sessionKey);
      } catch (error) {
        console.error("Failed to decrypt message:", error);
        return "Unable to decrypt message";
      }
    }
    return msg.content;
  };

  if (!activeConversationId || !activeConversation) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-light-gray p-4">
        <Shield className="h-16 w-16 text-teal mb-4" />
        <h2 className="text-2xl font-semibold text-gray-700 mb-2">
          Welcome to EncryptiFy
        </h2>
        <p className="text-gray-500 text-center max-w-md mb-4">
          Your messages are secured with end-to-end encryption. Start a conversation to begin chatting securely.
        </p>
        <div className="flex space-x-2">
          <div className="flex items-center space-x-2 bg-white p-3 rounded-lg shadow-sm">
            <Lock className="h-5 w-5 text-teal" />
            <span className="text-sm">End-to-End Encryption</span>
          </div>
          <div className="flex items-center space-x-2 bg-white p-3 rounded-lg shadow-sm">
            <Shield className="h-5 w-5 text-teal" />
            <span className="text-sm">Secure Storage</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-light-gray">
      {/* Chat header */}
      <div className="flex items-center justify-between bg-white border-b p-4">
        <div className="flex items-center space-x-3">
          <Avatar>
            <AvatarFallback className="bg-teal text-navy">
              {otherParticipant ? getInitials(otherParticipant.username) : "?"}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">{otherParticipant?.username}</p>
            <div className="flex items-center text-xs text-gray-500">
              {otherParticipant?.isOnline && (
                <span className="h-2 w-2 rounded-full bg-green-400 mr-1" />
              )}
              <span>
                {otherParticipant?.isOnline
                  ? "Online"
                  : otherParticipant?.lastSeen
                  ? `Last seen ${new Date(otherParticipant?.lastSeen).toLocaleTimeString()}`
                  : "Offline"}
              </span>
              <EncryptionInfo conversationId={activeConversationId} />
            </div>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="ghost" size="icon">
            <Phone className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Video className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="flex flex-col space-y-4">
          {/* Security banner */}
          <div className="flex justify-center mb-4">
            <div className="flex items-center space-x-2 bg-navy text-white px-4 py-2 rounded-full text-xs">
              <Lock className="h-3 w-3" />
              <span>Messages are end-to-end encrypted</span>
            </div>
          </div>

          {activeConversation.messages.map((msg) => {
            const isSender = msg.senderId === user?.id;
            const content = getMessageContent(msg);

            return (
              <div
                key={msg.id}
                className={`flex ${isSender ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    isSender
                      ? "bg-teal text-white rounded-br-none"
                      : "bg-white text-gray-800 rounded-bl-none"
                  }`}
                >
                  <p>{content}</p>
                  <div
                    className={`flex items-center justify-end mt-1 space-x-1 ${
                      isSender ? "text-white/80" : "text-gray-500"
                    }`}
                  >
                    <span className="text-xs">
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                    {isSender && (
                      <div className="text-xs">
                        {msg.status === "read" ? (
                          <span className="text-white">✓✓</span>
                        ) : msg.status === "delivered" ? (
                          <span>✓✓</span>
                        ) : (
                          <span>✓</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>

      {/* Input area */}
      <div className="p-4 bg-white border-t">
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type a secure message..."
            className="flex-1"
          />
          <Button type="submit" className="bg-teal hover:bg-teal/90">
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </div>
  );
};
