
import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useAuthStore } from '@/utils/authStore';
import { useChatStore } from '@/utils/chatStore';
import { LockKeyhole, Shield, RefreshCw, Key, Info } from 'lucide-react';

export const EncryptionInfo = ({ conversationId }: { conversationId?: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuthStore();
  const { conversations } = useChatStore();
  
  const conversation = conversationId ? 
    conversations.find(c => c.id === conversationId) : 
    undefined;
  
  const otherParticipant = conversation?.participants.find(p => p.id !== user?.id);
  
  // This is for demonstration. In a real app, we'd use actual encryption data
  const encryptionData = {
    algorithm: "AES-256-GCM",
    keyExchange: "ECDH P-384",
    fingerprint: user?.publicKey.substring(0, 8),
    sessionEstablished: conversation ? new Date().toISOString() : undefined,
    messageCount: conversation?.messages.length || 0,
  };
  
  const handleRefreshKeys = () => {
    // In a real app, this would initiate a new key exchange
    console.log("Refreshing encryption keys");
    // Show success message
    setTimeout(() => {
      setIsOpen(false);
    }, 1000);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="flex items-center space-x-1">
          <LockKeyhole className="h-4 w-4 text-teal" />
          <span className="text-xs text-teal">Encrypted</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-teal" />
            <span>Encryption Details</span>
          </DialogTitle>
          <DialogDescription>
            Your messages with {otherParticipant?.username || "this contact"} are secured using end-to-end encryption.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium text-sm text-gray-700 mb-2">Security Information</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between">
                <span className="text-gray-600">Encryption</span>
                <span className="font-mono">{encryptionData.algorithm}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-gray-600">Key Exchange</span>
                <span className="font-mono">{encryptionData.keyExchange}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-gray-600">Your Fingerprint</span>
                <span className="font-mono">{encryptionData.fingerprint}...</span>
              </li>
              {encryptionData.sessionEstablished && (
                <li className="flex justify-between">
                  <span className="text-gray-600">Session Established</span>
                  <span>{new Date(encryptionData.sessionEstablished).toLocaleString()}</span>
                </li>
              )}
              <li className="flex justify-between">
                <span className="text-gray-600">Messages Exchanged</span>
                <span>{encryptionData.messageCount}</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-navy/5 border border-navy/10 p-4 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="mt-1">
                <Info className="h-5 w-5 text-navy" />
              </div>
              <div>
                <h4 className="font-medium text-sm text-gray-700">What does end-to-end encryption mean?</h4>
                <p className="text-sm text-gray-600 mt-1">
                  With end-to-end encryption, your messages are secured with a lock, and only the recipient has the special key to unlock and read them. Not even EncryptiFy can read your messages.
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex justify-between items-center pt-2">
            <Button 
              variant="outline" 
              size="sm"
              className="text-sm text-teal border-teal hover:bg-teal hover:text-white"
              onClick={() => setIsOpen(false)}
            >
              Close
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              className="text-sm flex items-center space-x-1 text-teal border-teal hover:bg-teal hover:text-white"
              onClick={handleRefreshKeys}
            >
              <RefreshCw className="h-4 w-4" />
              <span>Refresh Keys</span>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
