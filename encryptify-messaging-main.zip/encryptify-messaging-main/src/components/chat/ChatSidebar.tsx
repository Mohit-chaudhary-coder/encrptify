
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuthStore } from "@/utils/authStore";
import { useChatStore } from "@/utils/chat/chatStore";
import { MessageSquare, Search, LogOut, UserPlus, CheckCheck } from "lucide-react";

export const ChatSidebar = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { 
    users, 
    conversations, 
    activeConversationId, 
    fetchUsers, 
    getOrCreateConversation, 
    setActiveConversation,
    setupSocketListeners
  } = useChatStore();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    
    setupSocketListeners();
    
    fetchUsers();
  }, [user, navigate, fetchUsers, setupSocketListeners]);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const handleUserSelect = async (userId: string) => {
    const conversation = await getOrCreateConversation(userId);
    setActiveConversation(conversation.id);
  };

  const handleConversationSelect = (conversationId: string) => {
    setActiveConversation(conversationId);
  };

  const getInitials = (name: string) => {
    return name.substring(0, 2).toUpperCase();
  };

  return (
    <div className="flex flex-col h-full w-80 bg-navy text-white border-r border-gray-700">
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <MessageSquare className="h-6 w-6 text-teal" />
          <h1 className="font-bold text-xl">EncryptiFy</h1>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          className="text-gray-300 hover:text-white" 
          onClick={handleLogout}
        >
          <LogOut className="h-5 w-5" />
        </Button>
      </div>

      <div className="p-4 flex items-center space-x-3">
        <Avatar>
          <AvatarFallback className="bg-teal text-navy">
            {user?.username ? getInitials(user.username) : "U"}
          </AvatarFallback>
        </Avatar>
        <div>
          <p className="font-medium">{user?.username}</p>
          <p className="text-xs text-gray-300">Encrypted and secure</p>
        </div>
      </div>

      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input 
            placeholder="Search contacts" 
            className="pl-10 bg-navy border-gray-700 text-white placeholder:text-gray-400 focus:border-teal"
          />
        </div>
      </div>

      <Separator className="bg-gray-700" />

      <ScrollArea className="flex-1">
        {conversations.length > 0 && (
          <div className="p-2">
            <h2 className="px-4 py-2 text-xs font-semibold uppercase text-gray-400">Recent Conversations</h2>
            <div className="space-y-1">
              {conversations.map((conversation) => {
                const otherParticipant = conversation.participants.find(p => p.id !== user?.id);
                if (!otherParticipant) return null;
                
                const lastMessage = conversation.lastMessage;
                
                return (
                  <Button
                    key={conversation.id}
                    variant="ghost"
                    className={`w-full justify-start px-4 py-3 hover:bg-gray-700 ${
                      activeConversationId === conversation.id ? "bg-gray-700" : ""
                    }`}
                    onClick={() => handleConversationSelect(conversation.id)}
                  >
                    <div className="flex items-center w-full">
                      <Avatar className="h-9 w-9 mr-3">
                        <AvatarFallback className="bg-teal text-navy">
                          {getInitials(otherParticipant.username)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 text-left">
                        <div className="flex justify-between">
                          <p className="font-medium">{otherParticipant.username}</p>
                          {lastMessage && (
                            <span className="text-xs text-gray-400">
                              {new Date(lastMessage.timestamp).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                          )}
                        </div>
                        {lastMessage && (
                          <div className="flex items-center">
                            {lastMessage.senderId === user?.id && (
                              <div className="mr-1">
                                {lastMessage.status === 'read' ? (
                                  <CheckCheck className="h-3 w-3 text-teal" />
                                ) : lastMessage.status === 'delivered' ? (
                                  <CheckCheck className="h-3 w-3 text-gray-400" />
                                ) : (
                                  <CheckCheck className="h-3 w-3 text-gray-600" />
                                )}
                              </div>
                            )}
                            <p className="text-sm text-gray-400 truncate">
                              {lastMessage.encrypted ? "🔒 Encrypted message" : lastMessage.content}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </Button>
                );
              })}
            </div>
          </div>
        )}
        
        <div className="p-2">
          <h2 className="px-4 py-2 text-xs font-semibold uppercase text-gray-400">Contacts</h2>
          <div className="space-y-1">
            {users
              .filter(u => u.id !== user?.id)
              .map((u) => (
                <Button
                  key={u.id}
                  variant="ghost"
                  className="w-full justify-start px-4 hover:bg-gray-700"
                  onClick={() => handleUserSelect(u.id)}
                >
                  <Avatar className="h-9 w-9 mr-3">
                    <AvatarFallback className="bg-gray-700 text-white">
                      {getInitials(u.username)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-left">
                    <p className="font-medium">{u.username}</p>
                    <div className="flex items-center text-xs text-gray-400">
                      <span
                        className={`h-2 w-2 rounded-full mr-1 ${
                          u.isOnline ? "bg-green-400" : "bg-gray-500"
                        }`}
                      />
                      <span>
                        {u.isOnline
                          ? "Online"
                          : u.lastSeen
                          ? `Last seen ${new Date(u.lastSeen).toLocaleTimeString()}`
                          : "Offline"}
                      </span>
                    </div>
                  </div>
                </Button>
              ))}
          </div>
        </div>
      </ScrollArea>

      <div className="p-4">
        <Button className="w-full bg-teal hover:bg-teal/90 text-white">
          <UserPlus className="mr-2 h-4 w-4" /> New Chat
        </Button>
      </div>
    </div>
  );
};
