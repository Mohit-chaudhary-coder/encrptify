
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ChatSidebar } from "@/components/chat/ChatSidebar";
import { ChatWindow } from "@/components/chat/ChatWindow";
import { useAuthStore } from "@/utils/authStore";
import { initializeSocket, disconnectSocket } from "@/utils/socketClient";
import { toast } from "sonner";

const Chat = () => {
  const navigate = useNavigate();
  const { isLoggedIn } = useAuthStore();
  
  useEffect(() => {
    if (!isLoggedIn) {
      navigate("/login");
      return;
    }

    // Initialize socket connection when user is authenticated
    try {
      initializeSocket();
      toast.success("Connected to chat server successfully");
    } catch (error) {
      console.error("Failed to connect:", error);
      toast.error("Failed to connect to chat server. Please try again later.");
    }
    
    // Cleanup socket connection when component unmounts
    return () => {
      disconnectSocket();
    };
  }, [isLoggedIn, navigate]);

  if (!isLoggedIn) {
    return null;
  }

  return (
    <div className="min-h-screen flex">
      <ChatSidebar />
      <ChatWindow />
    </div>
  );
};

export default Chat;
