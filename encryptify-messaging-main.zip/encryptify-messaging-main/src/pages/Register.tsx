
import { RegisterForm } from "@/components/auth/RegisterForm";

const Register = () => {
  return (
    <div className="min-h-screen bg-navy flex items-center justify-center p-4">
      <RegisterForm />
    </div>
  );
};

export default Register;
