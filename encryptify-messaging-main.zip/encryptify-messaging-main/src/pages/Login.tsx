
import { LoginForm } from "@/components/auth/LoginForm";

const Login = () => {
  return (
    <div className="min-h-screen bg-navy flex items-center justify-center p-4">
      <LoginForm />
    </div>
  );
};

export default Login;
