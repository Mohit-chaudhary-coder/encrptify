
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Shield, LockKeyhole, KeyRound } from 'lucide-react';

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-navy flex flex-col">
      {/* Header */}
      <header className="p-4 flex justify-between items-center">
        <div className="flex items-center">
          <Shield className="h-8 w-8 text-teal mr-2" />
          <h1 className="text-2xl font-bold text-white">EncryptiFy</h1>
        </div>
        <div className="space-x-4">
          <Button variant="ghost" className="text-white hover:text-teal" onClick={() => navigate('/login')}>
            Login
          </Button>
          <Button className="bg-teal hover:bg-teal/90 text-white" onClick={() => navigate('/register')}>
            Register
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col md:flex-row items-center justify-center px-4 md:px-16 py-12">
        <div className="md:w-1/2 md:pr-12 text-center md:text-left">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Secure Messaging for Everyone</h2>
          <p className="text-lg text-gray-300 mb-8">
            End-to-end encryption keeps your conversations private and secure. 
            Only you and the people you're talking to can read your messages.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center md:justify-start">
            <Button 
              size="lg" 
              className="bg-teal hover:bg-teal/90 text-white"
              onClick={() => navigate('/register')}
            >
              Get Started
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-teal text-teal hover:text-white hover:bg-teal"
              onClick={() => navigate('/login')}
            >
              Login
            </Button>
          </div>
        </div>
        <div className="md:w-1/2 mt-12 md:mt-0 flex justify-center">
          <div className="relative w-full max-w-md">
            <div className="absolute -top-8 -right-8 w-32 h-32 bg-teal/20 rounded-full"></div>
            <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-teal/20 rounded-full"></div>
            <div className="bg-navy border-2 border-gray-700 rounded-xl p-6 shadow-xl relative z-10">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center space-x-2">
                  <div className="w-10 h-10 bg-teal rounded-full flex items-center justify-center">
                    <span className="text-navy font-semibold">JD</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">John Doe</p>
                    <div className="flex items-center space-x-1">
                      <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                      <span className="text-xs text-green-400">Online</span>
                    </div>
                  </div>
                </div>
                <LockKeyhole className="h-5 w-5 text-teal" />
              </div>
              
              <div className="space-y-4">
                <div className="bg-gray-700 text-white p-3 rounded-lg rounded-bl-none max-w-[70%]">
                  <p>Hi there! How are you doing?</p>
                  <p className="text-xs text-right mt-1">10:24 AM</p>
                </div>
                <div className="bg-teal text-white p-3 rounded-lg rounded-br-none max-w-[70%] ml-auto">
                  <p>Hey! I'm good, thanks for asking.</p>
                  <div className="flex items-center justify-end space-x-1 mt-1">
                    <span className="text-xs">10:26 AM</span>
                    <span className="text-xs">✓✓</span>
                  </div>
                </div>
                <div className="bg-gray-700 text-white p-3 rounded-lg rounded-bl-none max-w-[70%]">
                  <p>Great! Want to meet up later?</p>
                  <p className="text-xs text-right mt-1">10:27 AM</p>
                </div>
                <div className="bg-teal text-white p-3 rounded-lg rounded-br-none max-w-[70%] ml-auto">
                  <p>Sounds good! Where and when?</p>
                  <div className="flex items-center justify-end space-x-1 mt-1">
                    <span className="text-xs">Just now</span>
                    <span className="text-xs">✓</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 bg-gray-800 p-3 rounded-full flex items-center">
                <input 
                  type="text" 
                  placeholder="Type a secure message..." 
                  className="bg-transparent border-none text-white text-sm w-full focus:outline-none" 
                />
                <KeyRound className="h-5 w-5 text-teal ml-2" />
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Features Section */}
      <section className="py-12 px-4 bg-gray-900">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center text-white mb-12">Secured by Design</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-navy p-6 rounded-xl border border-gray-700">
              <div className="w-12 h-12 bg-teal/20 rounded-lg flex items-center justify-center mb-4">
                <LockKeyhole className="h-6 w-6 text-teal" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">End-to-End Encryption</h3>
              <p className="text-gray-400">
                Your messages are encrypted on your device and can only be decrypted by the recipient.
              </p>
            </div>
            
            <div className="bg-navy p-6 rounded-xl border border-gray-700">
              <div className="w-12 h-12 bg-teal/20 rounded-lg flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-teal" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Secure Authentication</h3>
              <p className="text-gray-400">
                Strong password policies and secure authentication keep your account protected.
              </p>
            </div>
            
            <div className="bg-navy p-6 rounded-xl border border-gray-700">
              <div className="w-12 h-12 bg-teal/20 rounded-lg flex items-center justify-center mb-4">
                <KeyRound className="h-6 w-6 text-teal" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Unique Key Generation</h3>
              <p className="text-gray-400">
                Every conversation uses unique encryption keys to ensure maximum privacy.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy border-t border-gray-800 py-8 px-4">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <Shield className="h-6 w-6 text-teal mr-2" />
            <span className="text-white font-bold">EncryptiFy</span>
          </div>
          <div className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} EncryptiFy. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
